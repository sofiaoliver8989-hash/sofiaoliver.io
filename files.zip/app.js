document.getElementById('add-btn').addEventListener('click', function() {
  const input = document.getElementById('todo-input');
  const task = input.value.trim();
  if (task) {
    addTask(task);
    input.value = '';
  }
});

function addTask(task) {
  const li = document.createElement('li');
  li.textContent = task;

  const removeBtn = document.createElement('button');
  removeBtn.textContent = "Remove";
  removeBtn.onclick = function() {
    li.remove();
  };
  li.appendChild(removeBtn);

  document.getElementById('todo-list').appendChild(li);
}